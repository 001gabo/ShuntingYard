package com.shuntingyard.respository.implementations;

import com.shuntingyard.pojo.evaluate.response.EvaluateResponse;
import com.shuntingyard.services.evaluate.interfaces.IEvaluator;
import com.shuntingyard.services.evaluate.interfaces.IOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.script.ScriptEngineManager;
import javax.script.ScriptEngine;
import javax.script.ScriptException;

import java.util.*;

@Service
public class EvaluatorImpl implements IEvaluator {

    private Logger log;
    private IOperations iOperations;

    public EvaluatorImpl(IOperations iOperations){
        this.iOperations = iOperations;
        this.log =  LoggerFactory.getLogger(getClass());
    }

    @Override
    public EvaluateResponse getEvaluateResponse(String equation) {

        EvaluateResponse evaluateResponse = new EvaluateResponse();

        double valueCalculated;
        Stack pilaNumeros = new Stack();
        Stack pilaOperadores = new Stack();
        LinkedList cola = new LinkedList();

        for(char ch: equation.toCharArray()){
            if(Character.isDigit(ch)){
                pilaNumeros.push(ch);
            }else{
                switch(ch){
                    case '+':
                        pilaOperadores.push(ch);
                        iOperations = new SumaImpl();
                        iOperations.getResult(1,1);
                        break;
                    case '-':
                        pilaOperadores.push(ch);
                        iOperations = new RestaImpl();
                        iOperations.getResult(1,1);
                        break;
                    case '*':
                        pilaOperadores.push(ch);
                        iOperations = new MultiplicacionImpl();
                        iOperations.getResult(1,1);
                        break;
                    case '/':
                        pilaOperadores.push(ch);
                        iOperations = new DivisionImpl();
                        iOperations.getResult(1,1);
                        break;
                }
            }
        }

        try {
            ScriptEngineManager mgr = new ScriptEngineManager();
            ScriptEngine engine = mgr.getEngineByName("JavaScript");
            System.out.println(engine.eval(equation));
        } catch (ScriptException e) {
            e.printStackTrace();
        }

        return evaluateResponse;
    }

    private EvaluateResponse parserToDTO(EvaluateResponse evaluateResponse,String infixExp, String postfixExp,double value){

        evaluateResponse.setInfix(infixExp);
        evaluateResponse.setPostfix(postfixExp);
        evaluateResponse.setResult(value);

        return  evaluateResponse;
    }



}
