package com.shuntingyard.controller;

import com.shuntingyard.pojo.evaluate.response.EvaluateResponse;
import com.shuntingyard.process.EvaluateProcess;
import org.springframework.core.env.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@PropertySource("classpath:configuration.properties")
@RequestMapping("${service.url}")
public class EvaluateController {

    private Logger log;
    private Environment env;
    private EvaluateProcess evaluateProcess;

    public EvaluateController(Environment env, EvaluateProcess evaluateProcess){
        this.env = env;
        this.evaluateProcess = evaluateProcess;
        this.log =  LoggerFactory.getLogger(getClass());
    }

    @PostMapping("${service.url.endpoint.evaluate}")
    public ResponseEntity<?> EvaluateInfix(@RequestBody String equation){

        EvaluateResponse evaluateResponse = new EvaluateResponse();

        log.info("EvaluateController - Request: {}", equation);

        try {
            if(equation.contains("(")||equation.contains(")") || equation.substring(0,1) == "-"){

                evaluateResponse.setMessage(env.getProperty("service.response.bad.request"));
                return new ResponseEntity<> (evaluateResponse, HttpStatus.BAD_REQUEST);

            }else{
                evaluateResponse = evaluateProcess.process(equation);
                log.info("EvaluateController - Response: {}", evaluateResponse);
                return new ResponseEntity<> (evaluateResponse, HttpStatus.OK);
            }
        }catch (Exception e){
            log.error("EquationValidator - error: {}",e.getMessage());
            evaluateResponse.setMessage(env.getProperty("service.response.internal.error"));
            return new ResponseEntity<> (evaluateResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

}
