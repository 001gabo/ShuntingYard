package com.shuntingyard.services.evaluate.interfaces;


public interface IOperations {
    public double getResult(double number1, double number2);
}
