package com.shuntingyard.services.evaluate.interfaces;

public interface IEvaluator<T> {
    public T getEvaluateResponse(String equation);
}
