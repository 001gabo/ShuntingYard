package com.shuntingyard.utils;

public class ValidatePreference {

    public static int checkPreference(String character){

        if(character == "+" || character == "-"){
            return 1;
        }else if(character == "*" || character == "/"){
            return 2;
        }else{
            return 0;
        }
    }
}
