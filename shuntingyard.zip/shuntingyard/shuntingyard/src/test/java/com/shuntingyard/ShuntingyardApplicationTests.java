package com.shuntingyard;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShuntingyardApplicationTests {

	@Test
	void contextLoads() {
	}

}
