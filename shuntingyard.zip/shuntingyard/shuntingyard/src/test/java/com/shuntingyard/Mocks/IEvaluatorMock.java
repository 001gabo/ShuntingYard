package com.shuntingyard.Mocks;

import com.shuntingyard.pojo.evaluate.response.EvaluateResponse;
import com.shuntingyard.services.evaluate.interfaces.IEvaluator;

public class IEvaluatorMock implements IEvaluator {
    @Override
    public EvaluateResponse getEvaluateResponse(String equation) {
        EvaluateResponse evaluateResponse = new EvaluateResponse();
        evaluateResponse.setInfix(equation);
        evaluateResponse.setPostfix("23+");
        evaluateResponse.setResult(5.0);
        return evaluateResponse;
    }
}
