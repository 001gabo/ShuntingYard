package com.shuntingyard.controller;

import com.shuntingyard.Mocks.IEvaluatorMock;
import com.shuntingyard.Mocks.MockEnv;
import com.shuntingyard.process.EvaluateProcess;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

class EvaluateControllerTest {

    @Test
    public void evaluateInfix_OK() {

        String equation = "2+3";
        MockEnv mockEnv = new MockEnv();
        IEvaluatorMock iEvaluator = new IEvaluatorMock();
        EvaluateProcess evaluateProcess = new EvaluateProcess(iEvaluator);

        EvaluateController evaluateController = new EvaluateController(mockEnv,evaluateProcess);
        assertNotNull(evaluateController.EvaluateInfix(equation));
    }

    @Test
    public void evaluateInfix_BAD_REQUEST() {

        String equation = "(2+3)";
        MockEnv mockEnv = new MockEnv();
        IEvaluatorMock iEvaluator = new IEvaluatorMock();
        EvaluateProcess evaluateProcess = new EvaluateProcess(iEvaluator);

        EvaluateController evaluateController = new EvaluateController(mockEnv,evaluateProcess);
        assertNotNull(evaluateController.EvaluateInfix(equation));
    }
}